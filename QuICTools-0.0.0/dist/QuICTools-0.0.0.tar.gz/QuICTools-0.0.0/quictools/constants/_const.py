import os as _os
import numpy as _np

data_root = _os.getenv("QuICDATA")
INIT_ISO = _np.array([[0], [0], [0], [0], [0], [0], [0], [0], [0], [1], [0], [0], [0], [0], [0], [0]])
I33 = 10
SPIN = 7.5
DIM = 16