from quictools.models.pspin._p_spins import (
    kicked_pSpin_U,
    APM,
    APM_spherical,
    APM_single,
)