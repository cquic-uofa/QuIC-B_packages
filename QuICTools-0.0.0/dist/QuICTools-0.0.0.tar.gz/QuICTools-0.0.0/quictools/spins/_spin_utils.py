import numpy as _np

def ang_mom(J=7.5,convention="Standard"):
    
    # norm of spin matrix is J*(J+1)*(2*J+1)/3
    m = _np.arange(J-1,-J-1,-1)
    v = _np.sqrt( J*(J+1) - m*(m+1)  )

    jx = (_np.diag(v,1) + _np.diag(v,-1))/2

    if convention=="Standard":
        jy = (_np.diag(v,1) + _np.diag(-v,-1))/(2j)
        jz = _np.diag(_np.arange(J,-J-1,-1))
    elif convention=="Reversed":
        jy = (_np.diag(-v,1) + _np.diag(v,-1))/(2j)
        jz = _np.diag(_np.arange(-J,J+1,1))
    else:
        raise ValueError("Invalid convention")

    return jx,jy,jz

def scs_from_unit_vector(n,J=7.5,convention="Standard"):
    # arguments
    #     n (3,1) double {mustBeUnitVector}
    #     options.J (1,1) double {mustBeHalfInteger,mustBeNonnegative} = 7.5
    #     options.convention (1,1) string {mustBeValidConvention} = "Standard"
    # end

    # generates spin coherent state from unit vector n in subspace with angular momentum J
    
    dim = int(2*J+1)
    
    nn = dim-1 # dimension - 1 (not to be confused with n)
    
    phi = _np.arctan2(n[1],n[0])  # azimuthal angle
    
    if convention=="Standard":
        s = 1
        ind = nn
    elif convention=="Reversed":
        s = -1
        ind = 0
    else:
        raise ValueError("Invalid convention")
    

    scs = _np.zeros((dim,1),dtype=_np.complex128)
    if n[2]==1:
        scs[nn-ind] = 1
        return scs
    if n[2]==-1:
        scs[ind] = 1
        return scs
    

    p = (s*n[2]+1)/2      # stands in for altitude angle
    
    # working in log space so funciton works for large spin
    base = nn*_np.log(p)/2
    step = (_np.log(1-p)-_np.log(p))/2
    
    r = _np.arange(0,nn+1).reshape(-1,1)
    phase = _np.exp(1j*phi*r)
    
    # base + step*r
    # each step multiply by sqrt((1-p)/p)  % multiply by phase later
    
    # if not special case, proceed to calculate binomial
    scs[0] = base
    
    for ii in range(1,nn+1):
        # scs[ii-1] = scs[ii-2] + step + _np.log( (nn-ii+2)/(ii-1) )/2
        scs[ii] = scs[ii-1] + step + _np.log( (nn-ii+1)/ii )/2
    
    scs = _np.exp(scs)*phase
    scs = scs / _np.linalg.norm(scs)
    return scs

def rand_haar_uni(J=7.5,ensemble="Unitary",domain="Complex"):
    # This algorithm follows the algorithm outlined in 
    #   Diaconis P., Shahshahani M. "The Subgroup Algorithm for Generating Uniform Random Variables" (2009)
    #
    # Draw random Unitary from circular orthogonal, unitary, or symplectic ensembles
    #
    
    dim = int(2*J+1)

    if domain=="Complex":
        dtype = _np.complex128
    elif domain=="Real":
        dtype = _np.float64
    else:
        raise ValueError("Invalid domain")

    U = _np.eye(dim,dtype=dtype)

    for ii in range(2,dim+1):

        v = _np.random.randn(ii,1).astype(dtype)
        if domain=="Complex":
            v += 1j*_np.random.randn(ii,1)

        # Householder transform
        v /= _np.linalg.norm(v)
        phi = v[-1]/_np.abs(v[-1])
        v *= phi.conj()
        v[-1] = v[-1]-1 # v is now dx
        v /= _np.linalg.norm(v)

        R = phi*(_np.eye(ii,dtype=dtype)-2*(v@v.T.conj()))

        U[:ii,:ii] = R@U[:ii,:ii]

    if ensemble=="Unitary":
        return U
    elif ensemble=="Orthogonal":
        return U.T@U
    elif ensemble=="Symplectic":
        if dim%2 == 1:
            raise ValueError("Symplectic matrix must have even dimension")
        rot = _np.zeros((dim,dim),dtype=dtype)
        for jj in range(1,dim//2+1):
            rot[2*jj-1,2*jj-2] = 1
            rot[2*jj-2,2*jj-1] = -1
            # rot(2*jj,2*jj-1) = 1;
            # rot(2*jj-1,2*jj) = -1;
        return rot@U.T@rot.T@U
    else:
        ValueError("Invalid ensemble")