import numpy as _np
from scipy.linalg import expm as _expm
from quictools.spins import (
    ang_mom as _ang_mom,
    scs_from_unit_vector as _scs_from_unit_vector,
)

def op_expect(op,state,complex=False):
    # domain to allow expectation values of complex objects
    # put state in correct shape or determine if density
    
    result = (state.T.conj()@op@state)[0,0]
    if complex:
        return result
    else:
        return _np.real(result)

def fotoc(U,n,steps,W=None,Ω=None,J=7.5,convention="Standard"):
    # TODO allow multiple Us

    if len(n)==2:
        # treat as polar coords (θ,φ)
        n = _np.array([ _np.sin( n[0] )*_np.cos( n[1] ),
                        _np.sin( n[0] )*_np.sin( n[1] ),
                        _np.cos( n[0] ) ])

    if Ω is None:
        Ω = 2*_np.pi/(2*J+1)
    if W is None:
        jx,jy,jz = _ang_mom(J=J,convention=convention)
        W = _expm( 1j*(n[0]*jx+n[1]*jy+n[2]*jz)*Ω )


    fotoc_step = 0
    state = _scs_from_unit_vector(n,J=J)

    for k in range(steps):
        state = U@state
        fotoc_step += _np.abs(op_expect(W,state,complex=True))**2

    return fotoc_step/steps