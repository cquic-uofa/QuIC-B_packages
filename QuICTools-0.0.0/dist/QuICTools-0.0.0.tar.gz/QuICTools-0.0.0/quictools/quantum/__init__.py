from quictools.quantum._quantum_tools import (
    op_expect,
    fotoc,
)