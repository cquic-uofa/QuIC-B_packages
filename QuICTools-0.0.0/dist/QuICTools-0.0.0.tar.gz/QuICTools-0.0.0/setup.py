from setuptools   import setup

setup(name = 'QuICTools',
      version='0.0.0',
      description='Useful functions for quantum numerics in QuIC B',
      author='Jon Pajaud',
      author_email='jpajaud@email.arizona.edu',
      packages = ['quictools','quictools.spins','quictools.models.pspin','quictools.quantum','quictools.constants']
)
    #   package_data={'quictools':['DocStrings/*.txt']}
# )

# run python setup.py bdist_egg
# resulting egg in in ./dist/ directory